#!/usr/bin/env python

from braingames.games.calc_game import calc_game


def main():
    calc_game()


if __name__ == '__main__':
    main()

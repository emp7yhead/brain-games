#!/usr/bin/env python

from braingames.games.prime_game import prime_game


def main():
    prime_game()


if __name__ == '__main__':
    main()

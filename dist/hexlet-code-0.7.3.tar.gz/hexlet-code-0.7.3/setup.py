# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['braingames', 'braingames.functions', 'braingames.games', 'braingames.scripts']

package_data = \
{'': ['*']}

install_requires = \
['prompt>=0.4.1,<0.5.0']

entry_points = \
{'console_scripts': ['brain-calc = braingames.scripts.brain_calc:main',
                     'brain-even = braingames.scripts.brain_even:main',
                     'brain-games = braingames.scripts.brain_games:main',
                     'brain-gcd = braingames.scripts.brain_gcd:main',
                     'brain-prime = braingames.scripts.brain_prime:main',
                     'brain-progression = '
                     'braingames.scripts.brain_progression:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.7.3',
    'description': 'Brain games - first project on hexlet',
    'long_description': None,
    'author': 'emp7yhead',
    'author_email': 'artyomkropp@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
